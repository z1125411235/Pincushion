Pincushion
----------

A specialized mesh renderer that draws something like a pincushion.

![gif](http://45.media.tumblr.com/52c19ea6669f1360cd6200a5905f6414/tumblr_o0j823NzYu1qio469o1_400.gif)
